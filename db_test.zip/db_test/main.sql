use db_test
create table customer(customer_id int identity(1,1) primary key,customer_name nvarchar(30));
create table balanceTable(customer_id int,balance float);
create table customertransaction(customer_cid int,withdraw char(1),deposit char(1),DateOfTrans date,Amount float);
alter table customertransaction add constraint f_key foreign key(customer_cid) references customer(customer_id);
insert into customer(customer_name) values('vani');
select * from customer;
select * from balanceTable;
select * from customertransaction;
insert into customertransaction(Amount,customer_cid,DateOfTrans,deposit,withdraw) values(100,1,'04-12-2022','y','n');