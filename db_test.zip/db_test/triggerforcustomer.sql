use db_test;
go
create trigger t_insertCustomer on customer
for insert
as
begin
declare
	@customer_id int;
	select @customer_id=customer_id from inserted as i where i.customer_id=customer_id;
	insert into balanceTable(customer_id,balance) values(@customer_id,1200);
	print 'balance record added';
end
go