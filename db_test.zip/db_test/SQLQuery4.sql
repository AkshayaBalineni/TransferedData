use db_test;
go
create trigger t_balanceAmount on customertransaction
for insert
as 
begin
	declare
		@balance float,
		@customerid int,
		@Wd char(1),
		@dp char(1),
		@amount float
		select @customerid=customer_cid,@amount=Amount,@Wd=withdraw,@dp=deposit from inserted i where i.customer_cid=customer_cid;
		select @balance=balance from balanceTable bt where bt.customer_id=@customerid;
		if(@Wd='y'and @dp='y')
		begin
			raiserror('cant add both',16,1);
			rollback transaction;
			return;
		end
		else if(@wd like 'y')
		begin
			if(@balance-@amount>=1000)
			begin
			update balanceTable set balancetable.balance=(@balance-@amount) where balancetable.customer_id=@customerid;
			end
			else
			begin
			raiserror('balance cant be less than 1000',16,1);
			rollback transaction;
			end
		end
		else if(@dp like 'y')
		begin
			update balanceTable set  balanceTable.balance=(@balance+@amount) where  balanceTable.customer_id=@customerid; 
		end
 end